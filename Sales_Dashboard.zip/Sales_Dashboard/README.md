# ⚡ AI Sales Performance Dashboard

A premium, AI-powered Streamlit dashboard for sales analytics with 6 interactive pages, real-time forecasting, anomaly detection, and customer segmentation.

## Features

### 🧠 AI Analytics Engine
- **Sales Forecasting** — Linear regression projecting 3 months ahead
- **Anomaly Detection** — Z-score flagging of unusual sales/profit patterns
- **Customer Segmentation** — K-Means ML clustering for RFM (Recency, Frequency, Monetary) analysis with auto-labeling
- **Smart Insights** — Auto-generated natural-language business insights

### 📄 6 Dashboard Pages
| Page | Description |
|------|-------------|
| 🏠 **Overview** | KPIs, revenue trends, forecasts, anomaly detection, geo map, AI insights |
| 🗺️ **Regional Analysis** | State & city performance, regional trends, margin comparisons |
| 📦 **Product Intelligence** | Category/sub-category analysis, top/bottom products, discount impact |
| 👥 **Customer Insights** | RFM segmentation, top customers, repeat vs one-time buyers |
| 💰 **Profitability** | Margin trends, loss-makers, discount-profit correlation |
| 🚚 **Logistics** | Shipping efficiency, delivery tiers, ship mode performance |

### 🎨 Premium Design
- Dark-mode glassmorphism with animated floating blobs
- Responsive multi-column layouts
- Smooth hover animations on KPI cards
- Google Fonts (Inter) for modern typography

## Getting Started

### Install dependencies

```bash
pip install -r requirements.txt
```

### Run the dashboard

```bash
streamlit run dashboard.py
```

The dashboard reads `data/train.csv` (Superstore-style dataset) and provides real-time interactive analytics.

## Tech Stack
- **Streamlit** — Web framework
- **Pandas / NumPy** — Data processing
- **Plotly** — Interactive visualizations
- **scikit-learn** — AI forecasting & analytics
