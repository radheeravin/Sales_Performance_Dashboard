"""
AI Sales Performance Dashboard
==============================
A premium Streamlit dashboard with 6 analytical pages, AI-powered insights,
sales forecasting, anomaly detection, and RFM customer segmentation.
"""

import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st
from sklearn.linear_model import LinearRegression
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from datetime import timedelta

# ─────────────────────────── CONSTANTS ───────────────────────────

STATE_ABBREV = {
    'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA',
    'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'Florida': 'FL', 'Georgia': 'GA',
    'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA',
    'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD',
    'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS', 'Missouri': 'MO',
    'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ',
    'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH',
    'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC',
    'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT',
    'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY',
}

CHART_COLORS = ["#4d89ff", "#ff5dbc", "#38ffd8", "#ffb347", "#7b58ff", "#28e7ff", "#ff6bca", "#5affdb"]

PLOTLY_LAYOUT = dict(
    plot_bgcolor='rgba(0,0,0,0)',
    paper_bgcolor='rgba(0,0,0,0)',
    font=dict(color='#c8d8f8', family='Inter, sans-serif', size=13),
    margin=dict(t=44, b=24, l=8, r=8),
    title_font=dict(size=16, color='#e8f0ff'),
)


# ─────────────────────────── DATA LOADING ───────────────────────────

@st.cache_data
def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["Order Date"] = pd.to_datetime(df["Order Date"], errors="coerce")
    df["Ship Date"] = pd.to_datetime(df["Ship Date"], errors="coerce")
    df["Order Month"] = df["Order Date"].dt.to_period("M").dt.to_timestamp()
    df["Sales"] = pd.to_numeric(df["Sales"], errors="coerce").fillna(0)
    df["Profit"] = pd.to_numeric(df["Profit"], errors="coerce").fillna(0)
    df["Quantity"] = pd.to_numeric(df["Quantity"], errors="coerce").fillna(0)
    df["Discount"] = pd.to_numeric(df["Discount"], errors="coerce").fillna(0)
    df["Shipping Days"] = (df["Ship Date"] - df["Order Date"]).dt.days.fillna(0).astype(int)
    df["State Code"] = df["State/Province"].map(STATE_ABBREV)
    df["Profit Margin"] = np.where(df["Sales"] != 0, df["Profit"] / df["Sales"], 0)
    df["Year"] = df["Order Date"].dt.year
    df["Quarter"] = df["Order Date"].dt.quarter
    df["Month Name"] = df["Order Date"].dt.strftime("%b")
    df["Day of Week"] = df["Order Date"].dt.day_name()
    return df.dropna(subset=["Order Date"]).copy()


# ─────────────────────────── AI ENGINE ───────────────────────────

class AIEngine:

    @staticmethod
    def forecast_sales(df: pd.DataFrame, periods: int = 3) -> pd.DataFrame:
        monthly = df.groupby("Order Month")["Sales"].sum().reset_index().sort_values("Order Month")
        if len(monthly) < 3:
            return pd.DataFrame()
        monthly["month_num"] = np.arange(len(monthly))
        X = monthly[["month_num"]].values
        y = monthly["Sales"].values
        model = LinearRegression().fit(X, y)
        last_month = monthly["Order Month"].max()
        future_nums = np.arange(len(monthly), len(monthly) + periods).reshape(-1, 1)
        future_dates = [last_month + pd.DateOffset(months=i + 1) for i in range(periods)]
        predictions = model.predict(future_nums)
        forecast_df = pd.DataFrame({"Order Month": future_dates, "Sales": predictions, "Type": "Forecast"})
        monthly["Type"] = "Actual"
        return pd.concat([monthly[["Order Month", "Sales", "Type"]], forecast_df], ignore_index=True)

    @staticmethod
    def detect_anomalies(df: pd.DataFrame, column: str = "Sales", threshold: float = 2.0) -> pd.DataFrame:
        monthly = df.groupby("Order Month")[column].sum().reset_index()
        if len(monthly) < 3:
            return monthly.assign(is_anomaly=False, z_score=0)
        mean_val = monthly[column].mean()
        std_val = monthly[column].std()
        if std_val == 0:
            monthly["z_score"] = 0
        else:
            monthly["z_score"] = (monthly[column] - mean_val) / std_val
        monthly["is_anomaly"] = monthly["z_score"].abs() > threshold
        return monthly

    @staticmethod
    def rfm_segmentation(df: pd.DataFrame) -> pd.DataFrame:
        max_date = df["Order Date"].max()
        rfm = df.groupby("Customer ID").agg(
            Customer_Name=("Customer Name", "first"),
            Recency=("Order Date", lambda x: (max_date - x.max()).days),
            Frequency=("Order ID", "nunique"),
            Monetary=("Sales", "sum"),
        ).reset_index()
        
        # Machine Learning: K-Means Clustering for Customer Segmentation
        if len(rfm) < 5:
            rfm["Segment"] = "🔄 Regular"
            return rfm
            
        X = rfm[["Recency", "Frequency", "Monetary"]]
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        kmeans = KMeans(n_clusters=5, random_state=42, n_init=10)
        rfm["Cluster"] = kmeans.fit_predict(X_scaled)
        
        # Auto-label clusters based on their characteristics
        cluster_means = rfm.groupby("Cluster")[["Recency", "Frequency", "Monetary"]].mean()
        
        # Normalize means to calculate a composite value score
        # High Monetary, High Frequency, and Low Recency indicates a top customer
        normalized_means = (cluster_means - cluster_means.min()) / (cluster_means.max() - cluster_means.min() + 1e-9)
        cluster_means["Value_Score"] = normalized_means["Monetary"] + normalized_means["Frequency"] - normalized_means["Recency"]
        
        # Sort clusters by Value Score to rank them
        ranked_clusters = cluster_means.sort_values("Value_Score", ascending=False).index.tolist()
        
        label_map = {
            ranked_clusters[0]: "🏆 Champion",
            ranked_clusters[1]: "💎 Loyal",
            ranked_clusters[2]: "🔄 Regular",
            ranked_clusters[3]: "🌱 New Customer",
            ranked_clusters[4]: "💤 Lost / At Risk"
        }
        
        rfm["Segment"] = rfm["Cluster"].map(label_map)
        return rfm

    @staticmethod
    def generate_insights(df: pd.DataFrame, metrics: dict) -> list:
        insights = []
        monthly = df.groupby("Order Month")["Sales"].sum().reset_index().sort_values("Order Month")
        if len(monthly) >= 2:
            recent = monthly.tail(3)["Sales"].mean()
            earlier = monthly.head(3)["Sales"].mean()
            if earlier > 0:
                change = (recent - earlier) / earlier * 100
                icon = "🟢" if change > 0 else "🔴"
                trend = "upward" if change > 0 else "downward"
                insights.append(("trend", f"{icon} Sales show a **{trend} trend** ({change:+.1f}% change, early vs recent months). {'Strong momentum — consider scaling ad spend.' if change > 10 else 'Monitor closely and review marketing strategy.'}"))

        top_cat = df.groupby("Category")["Sales"].sum().idxmax()
        top_cat_val = df.groupby("Category")["Sales"].sum().max()
        top_cat_pct = top_cat_val / df["Sales"].sum() * 100
        insights.append(("success", f"🏆 **{top_cat}** dominates with **${top_cat_val:,.0f}** ({top_cat_pct:.1f}% of revenue). Focus cross-sell and upsell strategies here."))

        if metrics["profit_margin"] < 0.10:
            insights.append(("danger", f"🚨 Profit margin is **{metrics['profit_margin']:.1%}** — critically below the 10% health threshold. Immediate pricing review recommended."))
        elif metrics["profit_margin"] < 0.15:
            insights.append(("warning", f"⚠️ Profit margin at **{metrics['profit_margin']:.1%}** — approaching the lower boundary. Review discount policies."))
        else:
            insights.append(("success", f"✅ Profit margin is healthy at **{metrics['profit_margin']:.1%}** — above industry benchmarks."))

        high_disc = df[df["Discount"] > 0.2]
        if len(high_disc) > 0:
            avg_margin_high = high_disc["Profit Margin"].mean()
            avg_margin_low = df[df["Discount"] <= 0.2]["Profit Margin"].mean()
            gap = avg_margin_low - avg_margin_high
            insights.append(("warning", f"💸 Heavy discounts (>20%) erode margins by **{gap:.1%}** ({avg_margin_high:.1%} vs {avg_margin_low:.1%}). Consider value-based pricing instead."))

        top_region = df.groupby("Region")["Sales"].sum().idxmax()
        top_region_pct = df.groupby("Region")["Sales"].sum().max() / df["Sales"].sum() * 100
        insights.append(("info", f"🗺️ **{top_region}** region accounts for **{top_region_pct:.1f}%** of total revenue — primary market concentration."))

        loss_count = df[df["Profit"] < 0]["Product Name"].nunique()
        total_loss = df[df["Profit"] < 0]["Profit"].sum()
        if loss_count > 0:
            insights.append(("danger", f"🚨 **{loss_count} products** generating **${abs(total_loss):,.0f}** in losses. Evaluate for discontinuation or repricing."))

        avg_ship = df["Shipping Days"].mean()
        late = (df["Shipping Days"] > 5).sum()
        late_pct = late / len(df) * 100 if len(df) > 0 else 0
        insights.append(("info", f"🚚 Average delivery: **{avg_ship:.1f} days**. **{late_pct:.1f}%** of orders exceed 5-day threshold."))

        return insights


# ─────────────────────────── STYLING ───────────────────────────

def set_style():
    st.markdown(
        """
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        :root { color-scheme: dark; }
        *, *::before, *::after { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif !important; }

        .stApp {
            background:
                radial-gradient(ellipse 600px 400px at 8% 10%, rgba(56,246,216,0.14), transparent),
                radial-gradient(ellipse 500px 350px at 92% 14%, rgba(255,93,188,0.12), transparent),
                radial-gradient(ellipse 400px 300px at 50% 85%, rgba(123,88,255,0.10), transparent),
                linear-gradient(180deg, #030a1c 0%, #071838 30%, #0f2550 60%, #0a1a3e 100%);
            color: #e4ecff;
            min-height: 100vh;
        }

        /* ── Animated Background Blobs ── */
        .page-overlay { position:fixed; top:0; left:0; width:100%; height:100%; pointer-events:none; z-index:0; }
        .page-overlay .blob { position:absolute; border-radius:50%; filter:blur(100px); opacity:0.22; }
        .page-overlay .blob.one   { top:6%;  left:3%;  width:380px; height:380px; background:rgba(56,246,216,0.35); animation:blobFloat 22s ease-in-out infinite; }
        .page-overlay .blob.two   { top:35%; right:4%; width:450px; height:450px; background:rgba(255,93,188,0.22); animation:blobFloat 28s ease-in-out infinite reverse; }
        .page-overlay .blob.three { bottom:5%; left:20%; width:400px; height:400px; background:rgba(123,88,255,0.28); animation:blobFloat 25s ease-in-out infinite 3s; }
        .page-overlay .blob.four  { top:60%; left:60%; width:300px; height:300px; background:rgba(77,137,255,0.18); animation:blobFloat 20s ease-in-out infinite 5s; }
        @keyframes blobFloat {
            0%,100% { transform: translate(0,0) scale(1) rotate(0deg); }
            25%     { transform: translate(30px,-20px) scale(1.05) rotate(2deg); }
            50%     { transform: translate(-15px,-35px) scale(1.08) rotate(-1deg); }
            75%     { transform: translate(-25px,15px) scale(1.03) rotate(1deg); }
        }

        /* ── Sidebar ── */
        .stSidebar, section[data-testid="stSidebar"] {
            background: linear-gradient(180deg, rgba(6,14,38,0.99) 0%, rgba(8,20,50,0.98) 100%) !important;
            border-right: 1px solid rgba(56,246,216,0.12);
        }
        .sidebar-brand { display:flex; align-items:center; gap:14px; margin-bottom:8px; }
        .sidebar-logo {
            width:44px; height:44px; border-radius:14px;
            background: linear-gradient(135deg, #4d89ff, #38ffd8);
            display:flex; align-items:center; justify-content:center;
            font-size:22px; box-shadow: 0 8px 24px rgba(56,246,216,0.25);
        }
        .sidebar-title { font-size:20px; font-weight:800; color:#ffffff; line-height:1.2; }
        .sidebar-subtitle { color:#7e99d4; font-size:12px; letter-spacing:0.08em; text-transform:uppercase; margin-top:2px; }
        .sidebar-divider { height:1px; background:linear-gradient(90deg,transparent,rgba(56,246,216,0.2),transparent); margin:20px 0; }
        .sidebar-status {
            display:flex; align-items:center; gap:8px;
            background:rgba(56,246,216,0.08); border:1px solid rgba(56,246,216,0.15);
            border-radius:12px; padding:10px 14px; margin-bottom:18px;
        }
        .status-dot { width:8px; height:8px; border-radius:50%; background:#38ffd8; animation:pulse 2s ease-in-out infinite; }
        @keyframes pulse { 0%,100% { opacity:1; box-shadow:0 0 0 0 rgba(56,246,216,0.5); } 50% { opacity:0.7; box-shadow:0 0 0 8px rgba(56,246,216,0); } }
        .status-text { color:#7ec8b8; font-size:12px; font-weight:500; }

        /* ── Header ── */
        .header-container { position:relative; z-index:1; margin-bottom:28px; }
        .header-row { display:flex; justify-content:space-between; align-items:flex-end; gap:24px; flex-wrap:wrap; }
        .header-copy { max-width:700px; }
        .label-pill {
            display:inline-flex; align-items:center; gap:8px;
            background: linear-gradient(135deg, rgba(77,137,255,0.25), rgba(56,246,216,0.20));
            border: 1px solid rgba(56,246,216,0.25);
            color:#c8e8ff; font-weight:600; font-size:11px;
            letter-spacing:0.16em; text-transform:uppercase;
            padding:8px 18px; border-radius:999px; margin-bottom:16px;
            backdrop-filter: blur(8px);
        }
        .label-pill .pill-dot { width:6px; height:6px; border-radius:50%; background:#38ffd8; animation:pulse 2s infinite; }
        .page-title {
            font-size:44px; margin:0; line-height:1.08; font-weight:900;
            background: linear-gradient(135deg, #ffffff 0%, #a8c8ff 50%, #38ffd8 100%);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
            background-clip:text;
        }
        .page-subtitle { color:#8da4d4; margin-top:12px; font-size:15px; line-height:1.6; max-width:560px; }
        .header-meta { display:flex; flex-direction:column; align-items:flex-end; gap:10px; }
        .date-badge {
            display:inline-flex; align-items:center; gap:10px;
            background:rgba(11,24,58,0.90); border:1px solid rgba(77,137,255,0.20);
            border-radius:16px; padding:12px 20px;
            backdrop-filter:blur(12px); box-shadow:0 8px 32px rgba(0,0,0,0.25);
        }
        .date-badge-icon { font-size:16px; }
        .date-badge-text { font-size:13px; color:#a8c0f0; font-weight:500; }
        .records-badge {
            display:inline-flex; align-items:center; gap:8px;
            background:rgba(56,246,216,0.08); border:1px solid rgba(56,246,216,0.15);
            border-radius:12px; padding:8px 16px;
        }
        .records-badge span { font-size:12px; color:#7ec8b8; font-weight:500; }

        /* ── KPI Cards ── */
        .kpi-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:16px; margin-bottom:32px; }
        @media (max-width:1200px) { .kpi-grid { grid-template-columns:repeat(3,1fr); } }
        @media (max-width:768px)  { .kpi-grid { grid-template-columns:repeat(2,1fr); } }
        .kpi-card {
            position:relative; overflow:hidden;
            background: rgba(10,22,55,0.85);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 20px; padding: 22px 22px 18px;
            backdrop-filter: blur(16px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.20), inset 0 1px 0 rgba(255,255,255,0.04);
            transition: transform 0.3s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.3s ease;
        }
        .kpi-card:hover { transform:translateY(-6px); box-shadow:0 20px 60px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.06); }
        .kpi-card::before {
            content:''; position:absolute; top:0; left:0; right:0; height:3px;
            border-radius:20px 20px 0 0;
        }
        .kpi-card.c1::before { background:linear-gradient(90deg,#4d89ff,#38ffd8); }
        .kpi-card.c2::before { background:linear-gradient(90deg,#38ffd8,#5affdb); }
        .kpi-card.c3::before { background:linear-gradient(90deg,#7b58ff,#4d89ff); }
        .kpi-card.c4::before { background:linear-gradient(90deg,#ffb347,#ff5dbc); }
        .kpi-card.c5::before { background:linear-gradient(90deg,#ff5dbc,#7b58ff); }
        .kpi-glow {
            position:absolute; top:-40px; right:-40px; width:120px; height:120px;
            border-radius:50%; opacity:0.08; pointer-events:none;
        }
        .kpi-card.c1 .kpi-glow { background:#4d89ff; }
        .kpi-card.c2 .kpi-glow { background:#38ffd8; }
        .kpi-card.c3 .kpi-glow { background:#7b58ff; }
        .kpi-card.c4 .kpi-glow { background:#ffb347; }
        .kpi-card.c5 .kpi-glow { background:#ff5dbc; }
        .kpi-icon { font-size:20px; margin-bottom:10px; display:block; }
        .kpi-label { color:#7e99d4; text-transform:uppercase; letter-spacing:0.14em; font-size:10.5px; font-weight:600; margin-bottom:8px; }
        .kpi-value { font-size:28px; font-weight:800; color:#ffffff; margin-bottom:6px; line-height:1; }
        .kpi-delta { display:inline-flex; align-items:center; gap:4px; font-size:12px; font-weight:600; padding:3px 10px; border-radius:8px; }
        .kpi-delta.up   { color:#38ffd8; background:rgba(56,246,216,0.10); }
        .kpi-delta.down { color:#ff5dbc; background:rgba(255,93,188,0.10); }
        .kpi-delta.flat { color:#7e99d4; background:rgba(126,153,212,0.10); }
        .kpi-sub { color:#5c7ab5; font-size:11px; margin-top:8px; font-weight:500; }

        /* ── Section Headers ── */
        .section-header {
            display:flex; align-items:center; gap:12px;
            font-size:17px; color:#d8e4ff; font-weight:700;
            margin:34px 0 18px; position:relative;
        }
        .section-header::before {
            content:''; width:4px; height:22px; border-radius:4px;
            background:linear-gradient(180deg,#4d89ff,#38ffd8);
            flex-shrink:0;
        }
        .section-header .sh-badge {
            margin-left:auto; font-size:11px; font-weight:500; color:#5c7ab5;
            background:rgba(77,137,255,0.08); border:1px solid rgba(77,137,255,0.12);
            padding:4px 12px; border-radius:8px;
        }

        /* ── Chart Containers ── */
        .chart-card {
            background: rgba(8,18,44,0.75);
            border: 1px solid rgba(255,255,255,0.05);
            border-radius: 24px; padding: 20px;
            backdrop-filter: blur(12px);
            box-shadow: 0 8px 40px rgba(0,0,0,0.18);
            margin-bottom: 16px;
            transition: border-color 0.3s ease;
        }
        .chart-card:hover { border-color: rgba(77,137,255,0.15); }
        .stPlotlyChart > div { border-radius:20px !important; overflow:hidden; }

        /* ── AI Insight Cards ── */
        .insight-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:14px; }
        @media (max-width:768px) { .insight-grid { grid-template-columns:1fr; } }
        .insight-card {
            position:relative; overflow:hidden;
            background: rgba(8,18,44,0.80);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: 18px; padding: 18px 20px;
            backdrop-filter: blur(12px);
            transition: transform 0.25s ease, border-color 0.3s ease;
        }
        .insight-card:hover { transform:translateY(-3px); border-color:rgba(77,137,255,0.20); }
        .insight-card::before { content:''; position:absolute; top:0; left:0; right:0; height:2px; }
        .insight-card.type-success::before { background:linear-gradient(90deg,#38ffd8,#5affdb); }
        .insight-card.type-warning::before { background:linear-gradient(90deg,#ffb347,#ffd700); }
        .insight-card.type-danger::before  { background:linear-gradient(90deg,#ff5dbc,#ff4444); }
        .insight-card.type-info::before    { background:linear-gradient(90deg,#4d89ff,#7b58ff); }
        .insight-card.type-trend::before   { background:linear-gradient(90deg,#4d89ff,#38ffd8); }
        .insight-tag {
            display:inline-flex; align-items:center; gap:4px;
            font-size:9px; font-weight:700; letter-spacing:0.14em; text-transform:uppercase;
            padding:3px 10px; border-radius:6px; margin-bottom:10px;
        }
        .insight-tag.tag-success { color:#38ffd8; background:rgba(56,246,216,0.12); }
        .insight-tag.tag-warning { color:#ffb347; background:rgba(255,179,71,0.12); }
        .insight-tag.tag-danger  { color:#ff5dbc; background:rgba(255,93,188,0.12); }
        .insight-tag.tag-info    { color:#4d89ff; background:rgba(77,137,255,0.12); }
        .insight-tag.tag-trend   { color:#a8c8ff; background:rgba(77,137,255,0.10); }
        .insight-line { color:#b0c4e8; font-size:13.5px; line-height:1.65; }

        /* ── AI Banner ── */
        .ai-banner {
            position:relative; overflow:hidden;
            background: linear-gradient(135deg, rgba(77,137,255,0.12) 0%, rgba(56,246,216,0.08) 50%, rgba(123,88,255,0.10) 100%);
            border: 1px solid rgba(56,246,216,0.15);
            border-radius: 22px; padding: 22px 28px; margin-bottom: 28px;
            display:flex; align-items:center; gap:18px;
            backdrop-filter: blur(12px);
        }
        .ai-banner::before {
            content:''; position:absolute; top:0; left:0; right:0; height:2px;
            background:linear-gradient(90deg,#4d89ff,#38ffd8,#7b58ff,#ff5dbc);
            background-size:300% 100%; animation:shimmer 4s linear infinite;
        }
        @keyframes shimmer { 0%{background-position:100% 0} 100%{background-position:-100% 0} }
        .ai-icon {
            width:48px; height:48px; border-radius:14px;
            background:linear-gradient(135deg,rgba(77,137,255,0.3),rgba(56,246,216,0.2));
            display:flex; align-items:center; justify-content:center;
            font-size:24px; flex-shrink:0;
            box-shadow:0 8px 24px rgba(56,246,216,0.15);
        }
        .ai-banner-title { color:#ffffff; font-weight:700; font-size:15px; margin-bottom:4px; }
        .ai-banner-text { color:#8da4d4; font-size:13px; line-height:1.5; }

        /* ── Data Tables ── */
        .stDataFrame { border-radius:16px; overflow:hidden; }
        .stDataFrame table { background:rgba(8,18,44,0.85) !important; }
        .stDataFrame th { background:rgba(77,137,255,0.10) !important; color:#a8c0f0 !important; font-weight:600 !important; text-transform:uppercase; font-size:11px !important; letter-spacing:0.08em; }

        /* ── Dashboard Block (generic) ── */
        .dashboard-block {
            background:rgba(8,18,44,0.75); border:1px solid rgba(255,255,255,0.05);
            border-radius:22px; padding:22px; backdrop-filter:blur(12px);
            box-shadow:0 8px 40px rgba(0,0,0,0.18);
        }
        .dashboard-block h3 { margin-top:0; color:#e8f0ff; font-size:16px; font-weight:700; }
        </style>
        """,
        unsafe_allow_html=True,
    )


# ─────────────────────────── HELPERS ───────────────────────────

def fmt(value, style="currency"):
    if style == "currency":
        if value is None:
            return "$0"
        if abs(value) >= 1_000_000:
            return f"${value / 1_000_000:,.2f}M"
        if abs(value) >= 1_000:
            return f"${value / 1_000:,.1f}K"
        return f"${value:,.0f}"
    if style == "pct":
        return f"{value:.1%}"
    if style == "int":
        return f"{value:,.0f}"
    return str(value)


def make_chart(fig):
    fig.update_layout(**PLOTLY_LAYOUT)
    fig.update_xaxes(showgrid=False, tickfont=dict(color='#7e99d4', size=11))
    fig.update_yaxes(showgrid=True, gridcolor='rgba(255,255,255,0.04)', tickfont=dict(color='#7e99d4', size=11), zeroline=False)
    return fig


def render_section(title, badge=""):
    badge_html = f"<span class='sh-badge'>{badge}</span>" if badge else ""
    st.markdown(f"<div class='section-header'>{title}{badge_html}</div>", unsafe_allow_html=True)


def render_ai_banner():
    st.markdown(
        """<div class="ai-banner">
            <div class="ai-icon">🧠</div>
            <div>
                <div class="ai-banner-title">AI-Powered Analytics Engine</div>
                <div class="ai-banner-text">Real-time machine learning — sales forecasting, anomaly detection, RFM segmentation, and automated business insights. All computed locally from your data.</div>
            </div>
        </div>""",
        unsafe_allow_html=True,
    )


def render_insights(insights: list):
    tag_map = {"success": "Positive", "warning": "Caution", "danger": "Alert", "info": "Insight", "trend": "Trend"}
    html = "<div class='insight-grid'>"
    for itype, text in insights:
        tag_label = tag_map.get(itype, "Info")
        html += f"""<div class='insight-card type-{itype}'>
            <div class='insight-tag tag-{itype}'>{tag_label}</div>
            <div class='insight-line'>{text}</div>
        </div>"""
    html += "</div>"
    st.markdown(html, unsafe_allow_html=True)


# ─────────────────────────── SIDEBAR ───────────────────────────

def sidebar_menu():
    st.sidebar.markdown(
        """<div class='sidebar-brand'>
            <div class='sidebar-logo'>⚡</div>
            <div>
                <div class='sidebar-title'>Sales AI</div>
                <div class='sidebar-subtitle'>Command Center</div>
            </div>
        </div>
        <div class='sidebar-divider'></div>
        <div class='sidebar-status'>
            <div class='status-dot'></div>
            <span class='status-text'>System Online — All Models Active</span>
        </div>""",
        unsafe_allow_html=True,
    )
    page = st.sidebar.radio("Navigate", [
        "🏠 Overview",
        "🗺️ Regional Analysis",
        "📦 Product Intelligence",
        "👥 Customer Insights",
        "💰 Profitability",
        "🚚 Logistics",
    ], index=0, label_visibility="collapsed")
    st.sidebar.markdown("<div class='sidebar-divider'></div>", unsafe_allow_html=True)
    st.sidebar.markdown("#### 🎛️ Filters")
    return page


def sidebar_filters(df: pd.DataFrame):
    min_date = df["Order Date"].min().date()
    max_date = df["Order Date"].max().date()
    date_range = st.sidebar.date_input("Date range", value=[min_date, max_date], min_value=min_date, max_value=max_date)
    region = st.sidebar.multiselect("Region", sorted(df["Region"].unique()), default=sorted(df["Region"].unique()))
    category = st.sidebar.multiselect("Category", sorted(df["Category"].unique()), default=sorted(df["Category"].unique()))
    segment = st.sidebar.multiselect("Segment", sorted(df["Segment"].unique()), default=sorted(df["Segment"].unique()))
    ship_mode = st.sidebar.multiselect("Ship Mode", sorted(df["Ship Mode"].unique()), default=sorted(df["Ship Mode"].unique()))
    return date_range, region, category, segment, ship_mode


def filter_data(df, date_range, region, category, segment, ship_mode):
    if len(date_range) == 2:
        s, e = pd.to_datetime(date_range[0]), pd.to_datetime(date_range[1])
        df = df[(df["Order Date"] >= s) & (df["Order Date"] <= e)]
    if region:
        df = df[df["Region"].isin(region)]
    if category:
        df = df[df["Category"].isin(category)]
    if segment:
        df = df[df["Segment"].isin(segment)]
    if ship_mode:
        df = df[df["Ship Mode"].isin(ship_mode)]
    return df


def compute_metrics(df, full_df=None):
    total_sales = df["Sales"].sum()
    total_profit = df["Profit"].sum()
    orders = df["Order ID"].nunique()
    customers = df["Customer ID"].nunique()
    m = {
        "total_sales": total_sales,
        "total_profit": total_profit,
        "orders": orders,
        "profit_margin": total_profit / total_sales if total_sales else 0,
        "avg_order": total_sales / orders if orders else 0,
        "total_quantity": df["Quantity"].sum(),
        "customers": customers,
        "avg_discount": df["Discount"].mean(),
    }
    # Compute period-over-period deltas if full data available
    if full_df is not None and len(df) > 0:
        months = df["Order Month"].sort_values().unique()
        if len(months) >= 2:
            mid = len(months) // 2
            first_half = df[df["Order Month"].isin(months[:mid])]
            second_half = df[df["Order Month"].isin(months[mid:])]
            fh_sales = first_half["Sales"].sum()
            sh_sales = second_half["Sales"].sum()
            m["sales_delta"] = (sh_sales - fh_sales) / fh_sales * 100 if fh_sales else 0
            fh_profit = first_half["Profit"].sum()
            sh_profit = second_half["Profit"].sum()
            m["profit_delta"] = (sh_profit - fh_profit) / fh_profit * 100 if fh_profit else 0
            fh_orders = first_half["Order ID"].nunique()
            sh_orders = second_half["Order ID"].nunique()
            m["orders_delta"] = (sh_orders - fh_orders) / fh_orders * 100 if fh_orders else 0
            fh_margin = fh_profit / fh_sales if fh_sales else 0
            sh_margin = sh_profit / sh_sales if sh_sales else 0
            m["margin_delta_pts"] = (sh_margin - fh_margin) * 100  # percentage points
            fh_aov = fh_sales / fh_orders if fh_orders else 0
            sh_aov = sh_sales / sh_orders if sh_orders else 0
            m["aov_delta"] = (sh_aov - fh_aov) / fh_aov * 100 if fh_aov else 0
        else:
            m["sales_delta"] = m["profit_delta"] = m["orders_delta"] = m["margin_delta_pts"] = m["aov_delta"] = 0
    else:
        m["sales_delta"] = m["profit_delta"] = m["orders_delta"] = m["margin_delta_pts"] = m["aov_delta"] = 0
    return m


# ─────────────────────────── KPI CARDS ───────────────────────────

def render_kpis(metrics):
    def delta_html(val, suffix="%", is_pts=False):
        if is_pts:
            cls = "up" if val >= 0 else "down"
            arrow = "↑" if val >= 0 else "↓"
            return f"<span class='kpi-delta {cls}'>{arrow} {abs(val):.1f}pp</span>"
        cls = "up" if val >= 0 else "down"
        if val == 0:
            cls = "flat"
        arrow = "↑" if val > 0 else ("↓" if val < 0 else "→")
        return f"<span class='kpi-delta {cls}'>{arrow} {abs(val):.1f}{suffix}</span>"

    cards = [
        ("c1", "💰", "Total Revenue", fmt(metrics["total_sales"]), delta_html(metrics["sales_delta"]), f"{metrics['customers']:,} customers"),
        ("c2", "📊", "Net Profit", fmt(metrics["total_profit"]), delta_html(metrics["profit_delta"]), "Bottom line performance"),
        ("c3", "🛒", "Orders", f"{metrics['orders']:,}", delta_html(metrics["orders_delta"]), f"Avg {metrics['total_quantity']/max(metrics['orders'],1):.1f} items/order"),
        ("c4", "📈", "Profit Margin", f"{metrics['profit_margin']:.1%}", delta_html(metrics["margin_delta_pts"], is_pts=True), "Revenue to profit ratio"),
        ("c5", "🎯", "Avg Order Value", fmt(metrics["avg_order"]), delta_html(metrics["aov_delta"]), f"Avg discount {metrics['avg_discount']:.0%}"),
    ]

    html = "<div class='kpi-grid'>"
    for cls, icon, label, value, delta, sub in cards:
        html += f"""<div class='kpi-card {cls}'>
            <div class='kpi-glow'></div>
            <span class='kpi-icon'>{icon}</span>
            <div class='kpi-label'>{label}</div>
            <div class='kpi-value'>{value}</div>
            {delta}
            <div class='kpi-sub'>{sub}</div>
        </div>"""
    html += "</div>"
    st.markdown(html, unsafe_allow_html=True)


# ─────────────────────────── PAGE: OVERVIEW ───────────────────────────

def render_overview(df, metrics):
    render_ai_banner()
    render_kpis(metrics)

    # ── Revenue Trend + Forecast ──
    render_section("Revenue Trend & AI Forecast", "Linear Regression · 3-Month Horizon")
    col1, col2 = st.columns([2, 1])
    with col1:
        forecast_df = AIEngine.forecast_sales(df, periods=3)
        if not forecast_df.empty:
            fig = go.Figure()
            actual = forecast_df[forecast_df["Type"] == "Actual"]
            predicted = forecast_df[forecast_df["Type"] == "Forecast"]
            fig.add_trace(go.Scatter(
                x=actual["Order Month"], y=actual["Sales"], mode="lines+markers", name="Actual Revenue",
                line=dict(color="#4d89ff", width=2.5), marker=dict(size=5, color="#4d89ff"),
                fill="tozeroy", fillcolor="rgba(77,137,255,0.08)",
            ))
            fig.add_trace(go.Scatter(
                x=pd.concat([actual["Order Month"].tail(1), predicted["Order Month"]]),
                y=pd.concat([actual["Sales"].tail(1), predicted["Sales"]]),
                mode="lines+markers", name="AI Forecast",
                line=dict(color="#38ffd8", width=2.5, dash="dot"),
                marker=dict(size=8, symbol="diamond", color="#38ffd8", line=dict(width=2, color="#0a1a3e")),
            ))
            # Add confidence band
            if len(actual) > 2:
                std = actual["Sales"].std() * 0.5
                fig.add_trace(go.Scatter(
                    x=pd.concat([predicted["Order Month"], predicted["Order Month"][::-1]]),
                    y=pd.concat([predicted["Sales"] + std, (predicted["Sales"] - std).iloc[::-1]]),
                    fill="toself", fillcolor="rgba(56,246,216,0.06)", line=dict(width=0),
                    name="Confidence Band", showlegend=True,
                ))
            fig = make_chart(fig)
            fig.update_layout(title="Sales Trend with 3-Month AI Forecast", legend=dict(bgcolor='rgba(0,0,0,0)', y=0.98, x=0.02))
            st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    with col2:
        profit_by_month = df.groupby("Order Month")["Profit"].sum().reset_index()
        colors = ["#38ffd8" if v >= 0 else "#ff5dbc" for v in profit_by_month["Profit"]]
        fig = go.Figure(go.Bar(x=profit_by_month["Order Month"], y=profit_by_month["Profit"], marker_color=colors, marker_line=dict(width=0)))
        fig = make_chart(fig)
        fig.update_layout(title="Monthly Profit (gain/loss)")
        # Add zero line
        fig.add_hline(y=0, line=dict(color="rgba(255,255,255,0.15)", width=1, dash="dash"))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    # ── Anomaly Detection + Category ──
    render_section("Anomaly Detection & Category Split", "Z-Score Analysis · σ > 2.0")
    col1, col2 = st.columns([1.2, 0.8])
    with col1:
        anomalies = AIEngine.detect_anomalies(df, "Sales")
        fig = go.Figure()
        normal = anomalies[~anomalies["is_anomaly"]]
        anomaly_pts = anomalies[anomalies["is_anomaly"]]
        fig.add_trace(go.Scatter(
            x=normal["Order Month"], y=normal["Sales"], mode="lines+markers", name="Normal",
            line=dict(color="#4d89ff", width=2), marker=dict(size=5),
        ))
        # Add mean reference
        mean_val = anomalies["Sales"].mean()
        fig.add_hline(y=mean_val, line=dict(color="rgba(255,179,71,0.4)", width=1, dash="dash"), annotation_text=f"Mean ${mean_val:,.0f}", annotation_font=dict(color="#ffb347", size=11))
        if not anomaly_pts.empty:
            fig.add_trace(go.Scatter(
                x=anomaly_pts["Order Month"], y=anomaly_pts["Sales"], mode="markers", name="⚠️ Anomaly",
                marker=dict(color="#ff5dbc", size=16, symbol="x", line=dict(width=2, color="#ffffff")),
            ))
        fig = make_chart(fig)
        fig.update_layout(title="Sales Anomaly Detection", legend=dict(bgcolor='rgba(0,0,0,0)'))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    with col2:
        cat_data = df.groupby("Category")["Sales"].sum().reset_index().sort_values("Sales", ascending=False)
        fig = px.pie(cat_data, names="Category", values="Sales", hole=0.62,
                     color_discrete_sequence=["#4d89ff", "#38ffd8", "#ff5dbc"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Revenue by Category")
        fig.update_traces(textinfo="label+percent", textfont=dict(size=12, color="#c8d8f8"))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    # ── Geo Map + Top States ──
    render_section("Geographic Intelligence", f"{df['State/Province'].nunique()} states")
    col1, col2 = st.columns([1.2, 0.8])
    with col1:
        state_sales = df.groupby("State/Province").agg(Sales=("Sales", "sum")).reset_index()
        state_sales["State Code"] = state_sales["State/Province"].map(STATE_ABBREV)
        valid = state_sales.dropna(subset=["State Code"])
        if not valid.empty:
            fig = px.choropleth(valid, locations="State Code", locationmode="USA-states", color="Sales", scope="usa",
                                color_continuous_scale=["#0a1633", "#122b5d", "#4d89ff", "#38ffd8", "#e8f0ff"], template="plotly_dark")
            fig = make_chart(fig)
            fig.update_layout(title="Revenue Heat Map", geo=dict(bgcolor='rgba(0,0,0,0)', lakecolor='rgba(0,0,0,0)'), coloraxis_colorbar=dict(title="", tickfont=dict(color='#7e99d4')))
            st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    with col2:
        top_states = state_sales.sort_values("Sales", ascending=True).tail(10)
        fig = px.bar(top_states, x="Sales", y="State/Province", orientation="h",
                     color="Sales", color_continuous_scale=["#122b5d", "#4d89ff", "#38ffd8"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Top 10 States", coloraxis_showscale=False)
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    # ── AI Insights ──
    render_section("🧠 AI-Generated Insights", "Auto-Analyzed")
    insights = AIEngine.generate_insights(df, metrics)
    render_insights(insights)


# ─────────────────────────── PAGE: REGIONAL ───────────────────────────

def render_regional(df, metrics):
    render_kpis(metrics)

    render_section("Regional Revenue Comparison", f"{df['Region'].nunique()} regions")
    col1, col2 = st.columns(2)
    with col1:
        region_data = df.groupby("Region").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"), Orders=("Order ID", "nunique")).reset_index().sort_values("Sales", ascending=False)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=region_data["Region"], y=region_data["Sales"], name="Sales", marker=dict(color="#4d89ff", line=dict(width=0))))
        fig.add_trace(go.Bar(x=region_data["Region"], y=region_data["Profit"], name="Profit", marker=dict(color="#38ffd8", line=dict(width=0))))
        fig = make_chart(fig)
        fig.update_layout(title="Sales & Profit by Region", barmode="group", legend=dict(bgcolor='rgba(0,0,0,0)'))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    with col2:
        region_data["Margin"] = np.where(region_data["Sales"] != 0, region_data["Profit"] / region_data["Sales"], 0)
        fig = go.Figure(go.Bar(
            x=region_data["Region"], y=region_data["Margin"],
            marker_color=["#38ffd8" if m >= 0.1 else "#ffb347" if m >= 0 else "#ff5dbc" for m in region_data["Margin"]],
            text=region_data["Margin"].map(lambda x: f"{x:.1%}"), textposition="outside", textfont=dict(color="#c8d8f8"),
        ))
        fig = make_chart(fig)
        fig.update_layout(title="Profit Margin by Region")
        fig.update_yaxes(tickformat=".0%")
        fig.add_hline(y=0.1, line=dict(color="rgba(255,179,71,0.3)", width=1, dash="dash"), annotation_text="10% target", annotation_font=dict(color="#ffb347", size=10))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("City-Level Performance", f"Top & Bottom")
    col1, col2 = st.columns(2)
    with col1:
        top_cities = df.groupby("City").agg(Sales=("Sales", "sum")).reset_index().sort_values("Sales", ascending=True).tail(15)
        fig = px.bar(top_cities, x="Sales", y="City", orientation="h", color="Sales", color_continuous_scale=["#122b5d", "#4d89ff", "#38ffd8"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Top 15 Cities by Revenue", coloraxis_showscale=False)
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        bottom_cities = df.groupby("City").agg(Profit=("Profit", "sum")).reset_index().sort_values("Profit").head(15)
        colors = ["#ff5dbc" if v < 0 else "#38ffd8" for v in bottom_cities["Profit"]]
        fig = go.Figure(go.Bar(x=bottom_cities["Profit"], y=bottom_cities["City"], orientation="h", marker_color=colors))
        fig = make_chart(fig)
        fig.update_layout(title="Bottom 15 Cities by Profit")
        fig.add_vline(x=0, line=dict(color="rgba(255,255,255,0.15)", width=1))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Regional Sales Over Time", "Monthly trend")
    regional_trend = df.groupby(["Order Month", "Region"]).agg(Sales=("Sales", "sum")).reset_index()
    fig = px.line(regional_trend, x="Order Month", y="Sales", color="Region", color_discrete_sequence=CHART_COLORS, template="plotly_dark", markers=True)
    fig = make_chart(fig)
    fig.update_layout(title="Monthly Revenue by Region", legend=dict(bgcolor='rgba(0,0,0,0)'))
    fig.update_traces(line=dict(width=2.5), marker=dict(size=5))
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("State Performance Table", f"{df['State/Province'].nunique()} states")
    state_perf = df.groupby("State/Province").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"), Orders=("Order ID", "nunique"), Avg_Discount=("Discount", "mean")).reset_index()
    state_perf["Margin"] = np.where(state_perf["Sales"] != 0, state_perf["Profit"] / state_perf["Sales"], 0)
    state_perf = state_perf.sort_values("Sales", ascending=False)
    display = state_perf.head(20).copy()
    display["Sales"] = display["Sales"].map(lambda x: f"${x:,.0f}")
    display["Profit"] = display["Profit"].map(lambda x: f"${x:,.0f}")
    display["Margin"] = display["Margin"].map(lambda x: f"{x:.1%}")
    display["Avg_Discount"] = display["Avg_Discount"].map(lambda x: f"{x:.1%}")
    st.dataframe(display, width='stretch', hide_index=True)


# ─────────────────────────── PAGE: PRODUCT INTELLIGENCE ───────────────────────────

def render_products(df, metrics):
    render_kpis(metrics)

    render_section("Category Performance", f"{df['Category'].nunique()} categories")
    col1, col2 = st.columns(2)
    with col1:
        cat_perf = df.groupby("Category").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum")).reset_index()
        fig = go.Figure()
        fig.add_trace(go.Bar(x=cat_perf["Category"], y=cat_perf["Sales"], name="Sales", marker=dict(color="#4d89ff", line=dict(width=0))))
        fig.add_trace(go.Bar(x=cat_perf["Category"], y=cat_perf["Profit"], name="Profit", marker=dict(color="#38ffd8", line=dict(width=0))))
        fig = make_chart(fig)
        fig.update_layout(title="Sales & Profit by Category", barmode="group", legend=dict(bgcolor='rgba(0,0,0,0)'))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        sub_cat = df.groupby("Sub-Category").agg(Sales=("Sales", "sum")).reset_index()
        fig = px.treemap(sub_cat, path=["Sub-Category"], values="Sales", template="plotly_dark",
                         color="Sales", color_continuous_scale=["#0a1633", "#122b5d", "#4d89ff", "#38ffd8"])
        fig = make_chart(fig)
        fig.update_layout(title="Sub-Category Revenue Map", coloraxis_showscale=False)
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Top & Bottom Products", "Revenue & Loss leaders")
    col1, col2 = st.columns(2)
    with col1:
        top_products = df.groupby("Product Name").agg(Sales=("Sales", "sum")).reset_index().sort_values("Sales", ascending=True).tail(10)
        fig = px.bar(top_products, x="Sales", y="Product Name", orientation="h", color="Sales", color_continuous_scale=["#4d89ff", "#38ffd8"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="🏆 Top 10 Revenue Products", coloraxis_showscale=False)
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        bottom = df.groupby("Product Name").agg(Profit=("Profit", "sum")).reset_index().sort_values("Profit").head(10)
        fig = px.bar(bottom, x="Profit", y="Product Name", orientation="h", color="Profit", color_continuous_scale=["#ff5dbc", "#ffb347"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="🚨 Top 10 Loss-Making Products", coloraxis_showscale=False)
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Discount Impact Analysis", "Pricing strategy")
    col1, col2 = st.columns(2)
    with col1:
        prod_disc = df.groupby("Sub-Category").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"), Discount=("Discount", "mean")).reset_index()
        fig = px.scatter(prod_disc, x="Discount", y="Profit", size="Sales", color="Profit", hover_name="Sub-Category",
                         color_continuous_scale=["#ff5dbc", "#ffb347", "#38ffd8"], template="plotly_dark", size_max=45)
        fig = make_chart(fig)
        fig.update_layout(title="Discount vs Profit by Sub-Category")
        fig.update_xaxes(tickformat=".0%")
        fig.add_hline(y=0, line=dict(color="rgba(255,255,255,0.12)", width=1, dash="dash"))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        df_copy = df.copy()
        df_copy["Discount Bucket"] = pd.cut(df_copy["Discount"], bins=[-0.01, 0, 0.1, 0.2, 0.3, 0.5, 1.0], labels=["0%", "1-10%", "11-20%", "21-30%", "31-50%", "50%+"])
        bucket_data = df_copy.groupby("Discount Bucket", observed=True).agg(Avg_Margin=("Profit Margin", "mean"), Count=("Order ID", "count")).reset_index()
        colors = ["#38ffd8" if m >= 0.05 else "#ffb347" if m >= 0 else "#ff5dbc" for m in bucket_data["Avg_Margin"]]
        fig = go.Figure(go.Bar(
            x=bucket_data["Discount Bucket"], y=bucket_data["Avg_Margin"], marker_color=colors,
            text=bucket_data["Avg_Margin"].map(lambda x: f"{x:.1%}"), textposition="outside", textfont=dict(color="#c8d8f8"),
        ))
        fig = make_chart(fig)
        fig.update_layout(title="Avg Margin by Discount Tier")
        fig.update_yaxes(tickformat=".0%")
        fig.add_hline(y=0, line=dict(color="rgba(255,255,255,0.12)", width=1, dash="dash"))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Sub-Category Performance Matrix")
    matrix = df.groupby("Sub-Category").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"), Quantity=("Quantity", "sum"), Avg_Discount=("Discount", "mean")).reset_index()
    matrix["Margin"] = np.where(matrix["Sales"] != 0, matrix["Profit"] / matrix["Sales"], 0)
    matrix = matrix.sort_values("Sales", ascending=False)
    disp = matrix.copy()
    disp["Sales"] = disp["Sales"].map(lambda x: f"${x:,.0f}")
    disp["Profit"] = disp["Profit"].map(lambda x: f"${x:,.0f}")
    disp["Margin"] = disp["Margin"].map(lambda x: f"{x:.1%}")
    disp["Avg_Discount"] = disp["Avg_Discount"].map(lambda x: f"{x:.1%}")
    st.dataframe(disp, width='stretch', hide_index=True)


# ─────────────────────────── PAGE: CUSTOMER INSIGHTS ───────────────────────────

def render_customers(df, metrics):
    render_kpis(metrics)

    render_section("🧬 AI Customer Segmentation (RFM)", "Recency · Frequency · Monetary")
    rfm = AIEngine.rfm_segmentation(df)
    col1, col2 = st.columns([1.2, 0.8])
    with col1:
        fig = px.scatter(rfm, x="Recency", y="Monetary", size="Frequency", color="Segment", hover_name="Customer_Name",
                         template="plotly_dark", color_discrete_sequence=["#38ffd8", "#4d89ff", "#ffb347", "#ff5dbc", "#7b58ff", "#28e7ff"], size_max=28)
        fig = make_chart(fig)
        fig.update_layout(title="Customer Segments — Recency vs Monetary", legend=dict(bgcolor='rgba(0,0,0,0)', font=dict(size=11)))
        fig.update_xaxes(title="Recency (days since last order)")
        fig.update_yaxes(title="Total Spend ($)")
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        seg_counts = rfm["Segment"].value_counts().reset_index()
        seg_counts.columns = ["Segment", "Count"]
        fig = px.pie(seg_counts, names="Segment", values="Count", hole=0.58,
                     color_discrete_sequence=["#38ffd8", "#4d89ff", "#ffb347", "#ff5dbc", "#7b58ff", "#28e7ff"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Segment Distribution")
        fig.update_traces(textinfo="label+percent", textfont=dict(size=11, color="#c8d8f8"))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Segment Metrics", f"{rfm['Customer ID'].nunique()} customers")
    seg_metrics = rfm.groupby("Segment").agg(Customers=("Customer ID", "count"), Avg_Spend=("Monetary", "mean"), Avg_Frequency=("Frequency", "mean"), Avg_Recency=("Recency", "mean")).reset_index().sort_values("Avg_Spend", ascending=False)
    disp = seg_metrics.copy()
    disp["Avg_Spend"] = disp["Avg_Spend"].map(lambda x: f"${x:,.0f}")
    disp["Avg_Frequency"] = disp["Avg_Frequency"].map(lambda x: f"{x:.1f} orders")
    disp["Avg_Recency"] = disp["Avg_Recency"].map(lambda x: f"{x:.0f} days")
    st.dataframe(disp, width='stretch', hide_index=True)

    render_section("Top 20 Customers", "By lifetime revenue")
    col1, col2 = st.columns(2)
    with col1:
        top_cust = df.groupby("Customer Name").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"), Orders=("Order ID", "nunique")).reset_index().sort_values("Sales", ascending=True).tail(20)
        fig = px.bar(top_cust, x="Sales", y="Customer Name", orientation="h", color="Profit",
                     color_continuous_scale=["#ff5dbc", "#4d89ff", "#38ffd8"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Revenue (color = Profit)", coloraxis_colorbar=dict(title="Profit", tickfont=dict(color='#7e99d4')))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        seg_sales = df.groupby("Segment").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum")).reset_index()
        fig = go.Figure()
        fig.add_trace(go.Bar(x=seg_sales["Segment"], y=seg_sales["Sales"], name="Sales", marker=dict(color="#4d89ff")))
        fig.add_trace(go.Bar(x=seg_sales["Segment"], y=seg_sales["Profit"], name="Profit", marker=dict(color="#38ffd8")))
        fig = make_chart(fig)
        fig.update_layout(title="Revenue by Customer Segment", barmode="group", legend=dict(bgcolor='rgba(0,0,0,0)'))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Repeat vs One-Time Buyers", "Retention analysis")
    cust_orders = df.groupby("Customer ID").agg(Orders=("Order ID", "nunique"), Sales=("Sales", "sum")).reset_index()
    cust_orders["Type"] = np.where(cust_orders["Orders"] > 1, "Repeat", "One-Time")
    type_summary = cust_orders.groupby("Type").agg(Customers=("Customer ID", "count"), Total_Sales=("Sales", "sum")).reset_index()
    col1, col2 = st.columns(2)
    with col1:
        fig = px.pie(type_summary, names="Type", values="Customers", hole=0.55, color_discrete_sequence=["#4d89ff", "#ff5dbc"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Customer Count")
        fig.update_traces(textinfo="label+percent+value", textfont=dict(size=12, color="#c8d8f8"))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        fig = px.pie(type_summary, names="Type", values="Total_Sales", hole=0.55, color_discrete_sequence=["#38ffd8", "#ffb347"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Revenue Share")
        fig.update_traces(textinfo="label+percent+value", textfont=dict(size=12, color="#c8d8f8"))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})


# ─────────────────────────── PAGE: PROFITABILITY ───────────────────────────

def render_profitability(df, metrics):
    render_kpis(metrics)

    render_section("Profit Margin Trend", "Dual-axis analysis")
    margin_trend = df.groupby("Order Month").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum")).reset_index()
    margin_trend["Margin"] = np.where(margin_trend["Sales"] != 0, margin_trend["Profit"] / margin_trend["Sales"], 0)
    fig = make_subplots(specs=[[{"secondary_y": True}]])
    fig.add_trace(go.Bar(
        x=margin_trend["Order Month"], y=margin_trend["Profit"], name="Profit",
        marker_color=["#38ffd8" if p >= 0 else "#ff5dbc" for p in margin_trend["Profit"]],
    ), secondary_y=False)
    fig.add_trace(go.Scatter(
        x=margin_trend["Order Month"], y=margin_trend["Margin"], name="Margin %",
        line=dict(color="#ffb347", width=3), mode="lines+markers", marker=dict(size=6, color="#ffb347"),
    ), secondary_y=True)
    fig.update_layout(**PLOTLY_LAYOUT, title="Monthly Profit & Margin Trend", legend=dict(bgcolor='rgba(0,0,0,0)'))
    fig.update_xaxes(showgrid=False)
    fig.update_yaxes(showgrid=True, gridcolor='rgba(255,255,255,0.04)', secondary_y=False)
    fig.update_yaxes(tickformat=".0%", showgrid=False, secondary_y=True)
    fig.add_hline(y=0, line=dict(color="rgba(255,255,255,0.10)", width=1), secondary_y=False)
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Profitability Breakdown", "By category & region")
    col1, col2 = st.columns(2)
    with col1:
        cat_profit = df.groupby("Category").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum")).reset_index()
        fig = go.Figure(go.Bar(
            x=cat_profit["Category"], y=cat_profit["Profit"],
            marker_color=["#38ffd8" if p >= 0 else "#ff5dbc" for p in cat_profit["Profit"]],
            text=cat_profit["Profit"].map(lambda x: f"${x:,.0f}"), textposition="outside", textfont=dict(color="#c8d8f8"),
        ))
        fig = make_chart(fig)
        fig.update_layout(title="Profit by Category")
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        region_profit = df.groupby("Region").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum")).reset_index()
        region_profit["Margin"] = np.where(region_profit["Sales"] != 0, region_profit["Profit"] / region_profit["Sales"], 0)
        fig = go.Figure(go.Bar(
            x=region_profit["Region"], y=region_profit["Margin"],
            marker_color=["#38ffd8" if m >= 0.1 else "#ffb347" if m >= 0 else "#ff5dbc" for m in region_profit["Margin"]],
            text=region_profit["Margin"].map(lambda x: f"{x:.1%}"), textposition="outside", textfont=dict(color="#c8d8f8"),
        ))
        fig = make_chart(fig)
        fig.update_layout(title="Profit Margin by Region")
        fig.update_yaxes(tickformat=".0%")
        fig.add_hline(y=0.1, line=dict(color="rgba(255,179,71,0.3)", width=1, dash="dash"), annotation_text="10% target", annotation_font=dict(color="#ffb347", size=10))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Margin Distribution & Discount Correlation")
    col1, col2 = st.columns(2)
    with col1:
        margins = df["Profit Margin"].clip(-2, 2)
        fig = px.histogram(margins, nbins=60, color_discrete_sequence=["#4d89ff"], template="plotly_dark", labels={"value": "Profit Margin", "count": "Orders"})
        fig = make_chart(fig)
        fig.update_layout(title="Order-Level Margin Distribution", showlegend=False)
        fig.update_xaxes(tickformat=".0%")
        fig.add_vline(x=0, line=dict(color="rgba(255,93,188,0.4)", width=1.5, dash="dash"), annotation_text="Break-even", annotation_font=dict(color="#ff5dbc", size=10))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        disc_profit = df.groupby("Sub-Category").agg(Avg_Discount=("Discount", "mean"), Avg_Margin=("Profit Margin", "mean"), Sales=("Sales", "sum")).reset_index()
        fig = px.scatter(disc_profit, x="Avg_Discount", y="Avg_Margin", size="Sales", hover_name="Sub-Category",
                         color="Avg_Margin", color_continuous_scale=["#ff5dbc", "#ffb347", "#38ffd8"], template="plotly_dark", size_max=40)
        fig = make_chart(fig)
        fig.update_layout(title="Discount vs Margin (Sub-Category)")
        fig.update_xaxes(tickformat=".0%", title="Avg Discount")
        fig.update_yaxes(tickformat=".0%", title="Avg Margin")
        fig.add_hline(y=0, line=dict(color="rgba(255,255,255,0.10)", width=1, dash="dash"))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("🚨 Loss-Making Products", f"{df[df['Profit'] < 0]['Product Name'].nunique()} products")
    loss = df[df["Profit"] < 0].groupby("Product Name").agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"), Quantity=("Quantity", "sum"), Avg_Discount=("Discount", "mean")).reset_index().sort_values("Profit")
    disp = loss.head(15).copy()
    disp["Sales"] = disp["Sales"].map(lambda x: f"${x:,.0f}")
    disp["Profit"] = disp["Profit"].map(lambda x: f"${x:,.0f}")
    disp["Avg_Discount"] = disp["Avg_Discount"].map(lambda x: f"{x:.0%}")
    st.dataframe(disp, width='stretch', hide_index=True)


# ─────────────────────────── PAGE: LOGISTICS ───────────────────────────

def render_logistics(df, metrics):
    # Logistics KPIs
    avg_ship = df["Shipping Days"].mean()
    same_day = (df["Shipping Days"] == 0).sum()
    late = (df["Shipping Days"] > 5).sum()
    late_pct = late / len(df) * 100 if len(df) > 0 else 0

    cards_html = "<div class='kpi-grid'>"
    log_items = [
        ("c1", "📦", "Avg Ship Days", f"{avg_ship:.1f}", "up" if avg_ship <= 4 else "down", f"{'On target' if avg_ship <= 4 else 'Above 4-day target'}"),
        ("c2", "⚡", "Same Day Ships", f"{same_day:,}", "flat", f"{same_day/len(df)*100:.1f}% of orders"),
        ("c3", "⏰", "Late (>5 days)", f"{late:,}", "down" if late > 0 else "up", f"{late_pct:.1f}% of orders"),
        ("c4", "🚀", "Ship Modes", f"{df['Ship Mode'].nunique()}", "flat", "Available options"),
        ("c5", "📋", "Total Shipped", f"{len(df):,}", "flat", "All shipments"),
    ]
    for cls, icon, label, value, d_cls, sub in log_items:
        cards_html += f"""<div class='kpi-card {cls}'><div class='kpi-glow'></div>
            <span class='kpi-icon'>{icon}</span>
            <div class='kpi-label'>{label}</div><div class='kpi-value'>{value}</div>
            <div class='kpi-sub'>{sub}</div></div>"""
    cards_html += "</div>"
    st.markdown(cards_html, unsafe_allow_html=True)

    render_section("Shipping Time Distribution", "Delivery speed analysis")
    col1, col2 = st.columns(2)
    with col1:
        fig = px.histogram(df, x="Shipping Days", nbins=20, color_discrete_sequence=["#4d89ff"], template="plotly_dark", labels={"Shipping Days": "Days to Ship", "count": "Orders"})
        fig = make_chart(fig)
        fig.update_layout(title="Distribution of Shipping Days", showlegend=False)
        fig.add_vline(x=avg_ship, line=dict(color="rgba(255,179,71,0.5)", width=1.5, dash="dash"), annotation_text=f"Avg {avg_ship:.1f}d", annotation_font=dict(color="#ffb347", size=11))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        ship_mode_perf = df.groupby("Ship Mode").agg(Avg_Days=("Shipping Days", "mean"), Orders=("Order ID", "count"), Sales=("Sales", "sum")).reset_index().sort_values("Avg_Days")
        fig = go.Figure(go.Bar(
            x=ship_mode_perf["Ship Mode"], y=ship_mode_perf["Avg_Days"],
            marker_color=["#38ffd8", "#4d89ff", "#ffb347", "#ff5dbc"][:len(ship_mode_perf)],
            text=ship_mode_perf["Avg_Days"].map(lambda x: f"{x:.1f}d"), textposition="outside", textfont=dict(color="#c8d8f8"),
        ))
        fig = make_chart(fig)
        fig.update_layout(title="Avg Shipping Days by Mode")
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Ship Mode Performance", "Revenue & margin")
    col1, col2 = st.columns(2)
    with col1:
        mode_sales = df.groupby("Ship Mode").agg(Sales=("Sales", "sum")).reset_index()
        fig = px.pie(mode_sales, names="Ship Mode", values="Sales", hole=0.58, color_discrete_sequence=["#38ffd8", "#4d89ff", "#ffb347", "#ff5dbc"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Revenue by Ship Mode")
        fig.update_traces(textinfo="label+percent", textfont=dict(size=12, color="#c8d8f8"))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        mode_profit = df.groupby("Ship Mode").agg(Profit=("Profit", "sum"), Sales=("Sales", "sum")).reset_index()
        mode_profit["Margin"] = np.where(mode_profit["Sales"] != 0, mode_profit["Profit"] / mode_profit["Sales"], 0)
        fig = go.Figure(go.Bar(
            x=mode_profit["Ship Mode"], y=mode_profit["Margin"],
            marker_color=["#38ffd8", "#4d89ff", "#ffb347", "#ff5dbc"][:len(mode_profit)],
            text=mode_profit["Margin"].map(lambda x: f"{x:.1%}"), textposition="outside", textfont=dict(color="#c8d8f8"),
        ))
        fig = make_chart(fig)
        fig.update_layout(title="Profit Margin by Ship Mode")
        fig.update_yaxes(tickformat=".0%")
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Regional Delivery Efficiency", "Geographic analysis")
    col1, col2 = st.columns(2)
    with col1:
        reg_ship = df.groupby("Region").agg(Avg_Days=("Shipping Days", "mean")).reset_index().sort_values("Avg_Days")
        fig = px.bar(reg_ship, x="Region", y="Avg_Days", color="Avg_Days", color_continuous_scale=["#38ffd8", "#ffb347", "#ff5dbc"], template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Avg Delivery Time by Region", coloraxis_showscale=False)
        fig.add_hline(y=4, line=dict(color="rgba(255,179,71,0.3)", width=1, dash="dash"), annotation_text="4-day target", annotation_font=dict(color="#ffb347", size=10))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    with col2:
        ship_trend = df.groupby(["Order Month", "Ship Mode"]).size().reset_index(name="Count")
        fig = px.area(ship_trend, x="Order Month", y="Count", color="Ship Mode", color_discrete_sequence=CHART_COLORS, template="plotly_dark")
        fig = make_chart(fig)
        fig.update_layout(title="Ship Mode Usage Over Time", legend=dict(bgcolor='rgba(0,0,0,0)'))
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})

    render_section("Delivery Tier Analysis", "Performance by speed")
    df_copy = df.copy()
    df_copy["Delivery Tier"] = pd.cut(df_copy["Shipping Days"], bins=[-1, 1, 3, 5, 7, 100], labels=["Same/Next Day", "2-3 Days", "4-5 Days", "6-7 Days", "7+ Days"])
    tier_data = df_copy.groupby("Delivery Tier", observed=True).agg(Orders=("Order ID", "count"), Avg_Sales=("Sales", "mean"), Avg_Profit=("Profit", "mean")).reset_index()
    disp = tier_data.copy()
    disp["Avg_Sales"] = disp["Avg_Sales"].map(lambda x: f"${x:,.2f}")
    disp["Avg_Profit"] = disp["Avg_Profit"].map(lambda x: f"${x:,.2f}")
    st.dataframe(disp, width='stretch', hide_index=True)


# ─────────────────────────── MAIN ───────────────────────────

def main():
    st.set_page_config(page_title="AI Sales Performance Dashboard", page_icon="⚡", layout="wide", initial_sidebar_state="expanded")
    set_style()

    page = sidebar_menu()
    df = load_data("data/train.csv")
    date_range, region, category, segment, ship_mode = sidebar_filters(df)
    filtered = filter_data(df, date_range, region, category, segment, ship_mode)

    if len(date_range) == 2:
        start_date, end_date = pd.to_datetime(date_range[0]), pd.to_datetime(date_range[1])
    else:
        start_date, end_date = df["Order Date"].min(), df["Order Date"].max()

    metrics = compute_metrics(filtered, df)

    # ── Header with animated blobs ──
    st.markdown(
        f"""
        <div class='page-overlay'>
            <div class='blob one'></div><div class='blob two'></div>
            <div class='blob three'></div><div class='blob four'></div>
        </div>
        <div class='header-container'>
            <div class='header-row'>
                <div class='header-copy'>
                    <div class='label-pill'><span class='pill-dot'></span> AI Sales Performance Dashboard</div>
                    <h1 class='page-title'>Command Center</h1>
                    <p class='page-subtitle'>Real-time analytics powered by machine learning — forecasting, anomaly detection, customer segmentation, and automated insights.</p>
                </div>
                <div class='header-meta'>
                    <div class='date-badge'>
                        <span class='date-badge-icon'>📅</span>
                        <span class='date-badge-text'>{start_date.strftime('%b %d, %Y')} → {end_date.strftime('%b %d, %Y')}</span>
                    </div>
                    <div class='records-badge'>
                        <span>📊 {len(filtered):,} records · {filtered['Customer ID'].nunique():,} customers</span>
                    </div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Route to page
    page_map = {
        "🏠 Overview": render_overview,
        "🗺️ Regional Analysis": render_regional,
        "📦 Product Intelligence": render_products,
        "👥 Customer Insights": render_customers,
        "💰 Profitability": render_profitability,
        "🚚 Logistics": render_logistics,
    }
    renderer = page_map.get(page, render_overview)
    renderer(filtered, metrics)


if __name__ == "__main__":
    main()
